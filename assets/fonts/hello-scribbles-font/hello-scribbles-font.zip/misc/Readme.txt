Hi,
Thank for downloading Hello Scribbles :)

This font is personal use only, clik this link to purchase commercial license :
https://fontbundles.net/wellscript-studio/578832-hello-scribbles-handwritten-font

If you need a custom or corporate license please contact us at: 
wellscriptstudio@gmail.com

if you want to give us a cup coffee, :)
https://paypal.me/wellscript

say hi to our store for more amazing fonts :
https://fontbundles.net/wellscript-studio

Follow our instagram for update : @wellscriptstudio

Thank you & Hope You Like It :)
Wellscript Studio
